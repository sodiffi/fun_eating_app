package com.mobilezme.tony.pesticsdedetect;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

public class FiveminDialog extends AppCompatActivity {
    ImageView btn_OK;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fivemin_dialog);
        btn_OK=findViewById(R.id.btn_OK);
        btn_OK.setOnTouchListener(btnOKOnTouch);
    }

    View.OnTouchListener btnOKOnTouch=new View.OnTouchListener(){
        @Override
        public boolean onTouch(View v, MotionEvent event) {
            FiveminDialog.this.finish();
            return true;
        }
    };
}

package com.mobilezme.tony.pesticsdedetect;

import android.content.Intent;
import android.graphics.drawable.Animatable;
import android.os.Bundle;
import android.os.Debug;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Scroller;

public class StepActivity extends AppCompatActivity {
    private ImageView step_start,step_backbtn,slide;
    private ScrollView stepscroll;
    private LinearLayout stepbg,stepframe;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.step);
        stepframe=findViewById(R.id.stepframe);
        step_start=findViewById(R.id.step_start);
        step_backbtn=findViewById(R.id.step_backbtn);
        stepscroll=findViewById(R.id.stepscroll);
        stepbg=findViewById(R.id.stepbg);
        slide=findViewById(R.id.slide);
        Animation animation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.alpha);
        slide.setAnimation(animation);

        stepscroll.setOnScrollChangeListener(new View.OnScrollChangeListener() {
            @Override
            public void onScrollChange(View v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {
                slide.setAnimation(null);
                slide.setVisibility(View.INVISIBLE);
                if(scrollY>=0&&scrollY<=800){
                    stepbg.setBackgroundResource(R.drawable.step1);
                }else if(scrollY>800&&scrollY<=1700){
                    stepbg.setBackgroundResource(R.drawable.step2);
                }else if(scrollY>1700&&scrollY<=2600){
                    stepbg.setBackgroundResource(R.drawable.step3);
                }else if(scrollY>2600&&scrollY<=3500){
                    stepbg.setBackgroundResource(R.drawable.step4);
                }else if(scrollY>3500&&scrollY<=4400){
                    stepbg.setBackgroundResource(R.drawable.step5);
                }else if(scrollY>4400&&scrollY<=4800){
                    stepbg.setBackgroundResource(R.drawable.step6);
                }else if(scrollY>4800){
                    stepbg.setBackgroundResource(R.drawable.step7);
                }
            }
        });

        step_start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Change2Test();
            }
        });
        step_backbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Change2index();
            }
        });
    }

    //ChangePage
    private void Change2Test(){
        Intent InTestActivity=new Intent();
        InTestActivity.setClass(StepActivity.this,TestActivity.class);
        startActivity(InTestActivity);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    //ChangePage
    private void Change2index(){
        Intent InTestActivity=new Intent();
        InTestActivity.setClass(StepActivity.this,MainActivity.class);
        startActivity(InTestActivity);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

}

package com.mobilezme.tony.pesticsdedetect;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Environment;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;

import static java.lang.Double.NaN;

public class ResultActivity extends AppCompatActivity {

    private ArrayList<double[]> points = new ArrayList<>();
    public Inhibition_Rate inhibition_rate;

    //UI
    private TextView percent;
    private ImageView Restartbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.result);
        percent = findViewById(R.id.percent);
        Restartbtn = findViewById(R.id.Restartbtn);
        Restartbtn.setOnTouchListener(RestartbtnOnTouch);

        //Get READ_PHONE_STATE permission and Get IMEI
        TelephonyManager mTelManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
        if (ActivityCompat.checkSelfPermission(ResultActivity.this,
                Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(ResultActivity.this,
                    new String[]{Manifest.permission.READ_PHONE_STATE},
                    1);
        }
        String IMEI = mTelManager.getDeviceId();

        //Send Data to Inhibition_rate
        Bundle bundle = getIntent().getExtras();
        points.add(0, bundle.getDoubleArray("PointOneR"));
        points.add(1, bundle.getDoubleArray("PointTwoR"));
        points.add(2, bundle.getDoubleArray("PointOneG"));
        points.add(3, bundle.getDoubleArray("PointTwoG"));
        points.add(4, bundle.getDoubleArray("PointOneB"));
        points.add(5, bundle.getDoubleArray("PointTwoB"));
        inhibition_rate = new Inhibition_Rate(points, this,IMEI);
        ChangePercent();
    }

    //改變UI的圖案
    private void ChangePercent() {
        int Rate = inhibition_rate.getInhibition_Rate();
        percent.setText(String.valueOf(Rate) + "%");
        if (Rate >= 0 && Rate <= 33)
            percent.setBackgroundResource(R.drawable.result_percent_3);
        else if (Rate >= 34 && Rate <= 66)
            percent.setBackgroundResource(R.drawable.result_percent_2);
        else if (Rate >= 67 && Rate <= 100)
            percent.setBackgroundResource(R.drawable.result_percent_1);
        else if(Rate<=0){
            percent.setBackgroundResource(R.drawable.result_percent_3);
            percent.setText("0%");
        }else{
            percent.setBackgroundResource(R.drawable.result_percent_1);
            percent.setText("100%");
        }
    }

    //ChangePage
    private void Change2Index() {
        Intent InTestActivity = new Intent();
        InTestActivity.setClass(ResultActivity.this, MainActivity.class);
        startActivity(InTestActivity);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    //ButtonEvent
    View.OnTouchListener RestartbtnOnTouch = new View.OnTouchListener() {
        @Override
        public boolean onTouch(View v, MotionEvent event) {
            Change2Index();
            return true;
        }
    };

}

class Inhibition_Rate {
    private final static int START_BLUE=61;
    private final static int END_BLUE=210;
    private final static double START_DATAPERCENT=25/100;
    private final static double END_DATAPERCENT=75/100;

    private ArrayList<double[]> points;
    private String phoneIMEI;
    private ExpoetExcel e = new ExpoetExcel();
    private Runnable runnableUpload = new Runnable() {
        @Override
        public void run() {
            String foldername = e.foldername;
            String path = Environment.getExternalStorageDirectory().getAbsolutePath();
            if (path != null) {
                path =path+"/PesticsdeTestDemo/"+foldername+".csv";
            }

            //FTP->Upload data to Server
            Ftp ftp=new Ftp();
            boolean connect=ftp.ftpConnect("120.106.210.250","admin","wj/61j4zj6gk4",21);
            boolean upload=ftp.ftpUpload(path,foldername+"_"+phoneIMEI+".csv","Public/PesticsdeTest_upload");
            ftp.ftpDisconnect();
        }
    };


    Inhibition_Rate(ArrayList<double[]> points,ResultActivity resultActivity,String IMEI){
        phoneIMEI=IMEI;
        this.points=points;
        if(askpermission(resultActivity)){
            Exportexcelfile();
        }
        e.writeCsv("Inhibition_Rate", String.valueOf(getInhibition_Rate()),"","");
        e.flush(resultActivity);
        //實驗結果上傳到伺服器
        new Thread(runnableUpload).start();

        /*已棄用
        //去除極端數值
        TakeOutExtremum(4);
        TakeOutExtremum(5);
        //利用最小平方法算出斜率
        slope[0]=Least_Squares(4);
        slope[1]=Least_Squares(5);
        //寫入檔案
        e.writeCsv("first_slope", String.valueOf(slope[0]),"","");
        e.writeCsv("second_slope", String.valueOf(slope[1]),"","");
        e.writeCsv("rate", String.valueOf(getInhibition_Rate()),"","");
        e.flush(resultActivity);
        */

    }
    //---------------------
    //檔案功能
    //---------------------

    //確認讀寫檔案的權限
    public boolean askpermission(ResultActivity resultActivity) {
        int permission = ActivityCompat.checkSelfPermission(resultActivity,
                Manifest.permission.WRITE_EXTERNAL_STORAGE);
        int permission2 = ActivityCompat.checkSelfPermission(resultActivity,
                Manifest.permission.READ_EXTERNAL_STORAGE);
        if (permission != PackageManager.PERMISSION_GRANTED || permission2 != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(resultActivity,
                    new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE},
                    1);
            return true;
        }
        return true;
    }

    //建立並寫入檔案資料
    public void Exportexcelfile(){
        e.open();
        e.writeCsv("Num","R","G","B");
        for(int j=0;j<2;j++) {
            for (int i = 0; i < points.get(j).length; i++) {
                e.writeCsv(String.valueOf(i), String.valueOf(points.get(j)[i]),String.valueOf(points.get(j+2)[i]),String.valueOf(points.get(j+4)[i]));
            }
            e.writeCsv("----","----","----","----");
        }

    }


    //數據分析
    //Which:
    //0->R前3分30秒數據
    //1->R後3分30秒數據
    //2->G前3分30秒數據
    //3->G後3分30秒數據
    //4->B前3分30秒數據
    //5->B後3分30秒數據
    public double GetData(int Which,String DataType){
        //取得開始位置和結束位置
        int StartPoint=(int)(points.get(Which).length*START_DATAPERCENT);
        int EndPoint=(int)(points.get(Which).length*END_DATAPERCENT);
        //判斷是要取得Blue還是Red或Green
        double Avg=0;
        switch (Which){
            //取得Red跟Green
            case 0: case 1: case 2: case 3:
                //先把點資訊由小排到大
                Arrays.sort(points.get(Which));
                //取得平均值
                for(int i=StartPoint;i<EndPoint;i++){
                    Avg+=points.get(Which)[i];
                }
                Avg/=(EndPoint-StartPoint);
                if(Which==0){
                    e.writeCsv("R_00:00~03:30_Avg", String.valueOf(Avg),"","");
                }else if(Which==1){
                    e.writeCsv("R_03:30~07:00_Avg", String.valueOf(Avg),"","");
                }else if(Which==2){
                    e.writeCsv("G_00:00~03:30_Avg", String.valueOf(Avg),"","");
                }else if(Which==3){
                    e.writeCsv("G_03:30~07:00_Avg", String.valueOf(Avg),"","");
                }
                return  Avg;
            //取得Blue
            case 4: case 5:
                StartPoint=(int)((double)(END_BLUE-START_BLUE)*START_DATAPERCENT);
                EndPoint=(int)((double)(END_BLUE-START_BLUE)*END_DATAPERCENT);
                //建立新的陣列  P(j)=B(i+1)-B(i)，取61(START_BLUE)到180(END_BLUE)的數值
                double[] P=new double[(END_BLUE-START_BLUE)];
                for(int i=START_BLUE,j=0;i<END_BLUE-1;i++,j++){
                    P[j]=points.get(Which)[i+1]-points.get(Which)[i];
                }
                Arrays.sort(P);
                if(DataType.equals("Avg")) {
                    for (int i = StartPoint; i < EndPoint; i++) {
                        Avg += P[i];
                    }
                    Avg /= (EndPoint - StartPoint);

                    if(Which==4){
                        e.writeCsv("B_00:00~03:30_Avg", String.valueOf(Avg),"","");
                    }else if(Which==5){
                        e.writeCsv("B_03:30~07:00_Avg", String.valueOf(Avg),"","");
                    }
                    return Avg;
                }else if(DataType.equals("cv")){
                    //計算標準差(SD)
                    double SDSquareTotal=0;
                    double SDTotal=0;
                    for(int i=StartPoint,j=0;i<EndPoint;i++,j++){
                        SDSquareTotal+=(P[i])*(P[i]);
                        SDTotal+=(P[i]);
                    }
                    double SD=Math.sqrt((SDSquareTotal/(EndPoint-StartPoint))-(SDTotal/(EndPoint-StartPoint))*(SDTotal/(EndPoint-StartPoint)));
                    double cv=SD/(SDTotal/(EndPoint-StartPoint));

                    if(Which==4){
                        e.writeCsv("B_00:00~03:30_cv", String.valueOf(cv),"","");
                    }else if(Which==5){
                        e.writeCsv("B_03:30~07:00_cv", String.valueOf(cv),"","");
                    }

                    return cv;
                }
            default:
                return NaN;
        }
    }

    //取得抑制率
    public int getInhibition_Rate(){
        int rate=-1;
        try{
            double RGAvg_One=(GetData(0,"avg")+GetData(2,"avg"))/2;
            double RGAvg_Two=(GetData(1,"avg")+GetData(3,"avg"))/2;
            double BlueAvg_One=GetData(4,"avg");
            double BlueAvg_Two=GetData(5,"avg");
            rate=(int)((1-((BlueAvg_Two*RGAvg_One)/(BlueAvg_One*RGAvg_Two)))*100);
            //光訊號穩定度

        }catch(Exception e){
            return -1;
        }
        return rate;
    }





    //--------------------------
    //已棄用
    //--------------------------

    //去除資料中的極值
    public void TakeOutExtremum(int Which){
        ArrayList extremum=new ArrayList();
        for(int i=1;i<points.get(Which).length-1;i++){
            double DisBefore,DisAfter;
            DisBefore = GetDistance(i, (int) points.get(Which)[i], i - 1, (int) points.get(Which)[i-1]);
            DisAfter=GetDistance(i,(int)points.get(Which)[i],i+1,(int)points.get(Which)[i+1]);
            if(DisBefore>20.0&&DisAfter>20.0)
                extremum.add(i);
            //----
            if(i==1){
                extremum.add(0);
            }else if(i==points.get(Which).length-2){
                DisBefore = GetDistance(i, (int) points.get(Which)[i], i + 1, (int)points.get(Which)[i+1]);
                DisAfter=GetDistance(i-1,(int)points.get(Which)[i-1],i+1,(int)points.get(Which)[i+1]);
                if(DisBefore>20.0&&DisAfter>20.0)
                    extremum.add(points.get(Which).length-1);
            }
            //----

        }

        for(int i=0;i<extremum.size();i++){
            points.get(Which)[(int)extremum.get(i)]= NaN;
        }

    }

    //最小平方法
    public double Least_Squares(int Which){
        int n=points.get(Which).length;
        int XY=0;
        int X=0;
        int Y=0;
        int XX=0;
        int Realn=0;
        for(int i=60;i<n;i++){
            if(points.get(Which)[i]!=NaN){
                Realn++;
                XY+=i*(int)points.get(Which)[i];
                X+=i;
                Y+=(int)points.get(Which)[i];
                XX+=i*i;
            }else{
                Log.d("SLOPE","被排除的點:"+(points.get(Which)[i]));
            }
        }

        Log.d("斜率","XY是"+XY);
        Log.d("斜率","X是"+X);
        Log.d("斜率","Y是"+Y);
        Log.d("斜率","XX是"+XX);
        Log.d("斜率","Realn是"+Realn);
        BigDecimal b_UP = new BigDecimal(Double.toString((Realn*XY-(X*Y))));
        BigDecimal b_DOWN = new BigDecimal(Double.toString((Realn*XX-X*X)));
        try {
            BigDecimal b = new BigDecimal(Double.toString(b_UP.doubleValue() / b_DOWN.doubleValue()));
            return b.setScale(3,BigDecimal.ROUND_HALF_UP).doubleValue();
        }catch (Exception e){
            return 0;
        }

    }

    //取得RGB中的R跟G加起來的平均值
    public double getR_G_Avg(int RWhich,int GWhich){
        double Avg;
        int n=points.get(RWhich).length;
        int temptotal=0;
        for(int i=60;i<n;i++){
            temptotal+=points.get(RWhich)[i];
            temptotal+=points.get(GWhich)[i];
        }
        Avg=temptotal/(n*2);
        return Avg;
    }

    //取得兩點之間的距離
    public double GetDistance(int oneX,int oneY,int twoX,int twoY){
        int DisY=twoY-oneY;
        int DisX=twoX-oneX;
        return Math.sqrt(DisY*DisY+DisX+DisX);
    }

}
class Test_Inhibition_Rate{
    private ArrayList[] points=new ArrayList[2];
    private Inhibition_Rate inhibition_rate;
    Test_Inhibition_Rate(){
        points[0]=new ArrayList();
        points[1]=new ArrayList();
        for(int i=0;i<300;i++){
            int j=i*3;
            points[0].add(i,j);
        }
        for(int i=0;i<300;i++){
            int j=i*2;
            points[1].add(i,j);
        }
        /*inhibition_rate=new Inhibition_Rate(points);
        int i=inhibition_rate.getInhibition_Rate();
        Log.d("Inhibition_Rate","SLOPE:"+String.valueOf(i));*/
    }

}

package com.mobilezme.tony.pesticsdedetect;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.util.Log;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ExpoetExcel {

    public static final String mComma = ",";
    private static StringBuilder mStringBuilder = null;
    private static String mFileName = null;
    public static String foldername="";

    public static void open() {
        String folderName = null;
        if(Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)){
            String path = Environment.getExternalStorageDirectory().getAbsolutePath();
            if (path != null) {
                folderName = path +"/PesticsdeTestDemo/";
            }
        }

        File fileRobo = new File(folderName);
        if(!fileRobo.exists()){
            fileRobo.mkdir();
        }
        SimpleDateFormat sdFormat = new SimpleDateFormat("yyyy_MM_dd_hh:mm:ss");
        Date date = new Date();
        String strDate = sdFormat.format(date);
        foldername=strDate;
        mFileName = folderName + foldername+".csv";
        mStringBuilder = new StringBuilder();
    }

    public static void writeCsv(String num, String R, String G, String B) {
        mStringBuilder.append(num);
        mStringBuilder.append(mComma);
        mStringBuilder.append(R);
        mStringBuilder.append(mComma);
        mStringBuilder.append(G);
        mStringBuilder.append(mComma);
        mStringBuilder.append(B);
        mStringBuilder.append("\n");
    }

    public static void flush(Context c) {
        if (mFileName != null) {
            try {
                File file = new File(mFileName);
                FileOutputStream fos = new FileOutputStream(file, false);
                fos.write(mStringBuilder.toString().getBytes());
                fos.flush();
                fos.close();
                Uri uri = Uri.fromFile(file);
                c.sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, uri));
                Log.d("Test", "Save!");
            } catch (FileNotFoundException e) {
                e.printStackTrace();
                Log.d("Test", String.valueOf(e));
            } catch (IOException e) {
                e.printStackTrace();
                Log.d("Test", String.valueOf(e));
            }
        } else {
            throw new RuntimeException("You should call open() before flush()");
        }
    }
}
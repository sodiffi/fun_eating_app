package com.mobilezme.tony.pesticsdedetect;


import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.ImageFormat;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CameraMetadata;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.Image;
import android.media.ImageReader;
import android.media.SoundPool;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.HandlerThread;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.util.Size;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class TestActivity extends AppCompatActivity {
    //實驗設定參數
    private final int PAUSEMIN = 3;
    private final int CheckPauseSec=30;
    private boolean IsPicCanTake = true;  //決定是否要取得照片
    private int TakePicTime = 1000;//取得照片的間隔時間
    private int PrepareTime = 3000;//準備啟動的時間
    private final static double START_LIGHTCHECK=15;
    private final static double END_LIGHTCHECK=30;
    private final static double START_DATAPERCENT=0.25;
    private final static double END_DATAPERCENT=0.75;
    private final static int START_BLUE=61;
    private final static int END_BLUE=210;

    //相機參數
    private final int REQUEST_PERMISSION_CAMERA = 100;
    private CameraDevice mcameraDevice;
    private CameraManager camMgr = null;
    private CaptureRequest.Builder mPreviewBuilder = null;
    private Size mPreviewSize = null;
    private ImageReader mImageReader = null;
    private CameraCaptureSession CameraSession = null;
    private String cameraID;

    private Handler mBackgroundHandler;
    private HandlerThread mBackgroundThread;

    //實驗參數
    private ArrayList[] SaveAvg_Blue = new ArrayList[3];
    private ArrayList[] SaveAvg_Red = new ArrayList[3];
    private ArrayList[] SaveAvg_Green = new ArrayList[3];
    private int[] CountPic = new int[3];
    private int SaveProcess = 0;//紀錄實驗階段 0=>第一階段 1=>第二階段
        //實驗過程   -1=>未開始實驗
        //          0=>檢查光源
        //          1=>第一階段實驗
        //          2=>第二階段實驗
        //          3=>完成實驗
    private int WhichProcess = 0;
    private int TextState=0;
    private int PauseMin = PAUSEMIN;
    private int Time = 0;
    private long PushBackbtnTime = 0;
    public boolean pause;
    public  long SpendTime = 0;
    private SoundPool soundpool;
    private Context c = this;

    //UI
    private TextView result,time;
    private ImageView Firstbtn,Secondbtn,Thirdbtn,backindex;


    private Handler Handler2TakePic = new Handler();
    private Runnable runnable2TakePic = new Runnable() {
        @Override
        public void run() {
            if (!pause) {
                IsPicCanTake = true;
            }
            Handler2TakePic.postDelayed(this, TakePicTime);
        }
    };
    private Handler Handler2CountTime = new Handler();
    private Runnable runnable2CountTime = new Runnable() {
        @Override
        public void run() {
            if (!pause) {
                //計時器即時更新時間
                String strtime = "";
                int min = Time / 60;
                int sec = Time % 60;
                if (min < 10)
                    strtime += "0";
                strtime += min + "\n";
                if (sec < 10)
                    strtime += "0";
                strtime += sec;
                time.setText(strtime);
                //即時更新畫面文字狀態
                switch (WhichProcess){
                    case 0:
                        switch (TextState){
                            case 0:
                                TextState++;
                                result.setText("裝置位置及穩定性檢查");break;
                            case 1:
                                TextState++;
                                result.setText("裝置位置及穩定性檢查.");break;
                            case 2:
                                TextState++;
                                result.setText("裝置位置及穩定性檢查..");break;
                            case 3:
                                TextState=0;
                                result.setText("裝置位置及穩定性檢查...");break;
                        }
                        break;
                    case 1:
                        switch (TextState){
                            case 0:
                                TextState++;
                                result.setText("第一階段實驗中");break;
                            case 1:
                                TextState++;
                                result.setText("第一階段實驗中.");break;
                            case 2:
                                TextState++;
                                result.setText("第一階段實驗中..");break;
                            case 3:
                                TextState=0;
                                result.setText("第一階段實驗中...");break;
                        }
                        break;
                    case 2:
                        switch (TextState){
                            case 0:
                                TextState++;
                                result.setText("第二階段實驗中");break;
                            case 1:
                                TextState++;
                                result.setText("第二階段實驗中.");break;
                            case 2:
                                TextState++;
                                result.setText("第二階段實驗中..");break;
                            case 3:
                                TextState=0;
                                result.setText("第二階段實驗中...");break;
                        }
                        break;
                    case 3:
                        result.setText("完成實驗");
                        //ChangeNextbtn();
                        pause=true;
                        break;
                }
                //判斷目前狀態
                //1.30秒的時候觸發"檢查光源"
                //2.3分30秒的時候觸發"加入蔬果汁&檢查數據是否正確"
                //3.7分鐘的時候觸發"完成實驗"
                if(sec>=CheckPauseSec&&WhichProcess==0){
                    TextState=0;
                    WhichProcess=1;
                    Firstbtn.setImageResource(R.drawable.ok);
                    Secondbtn.setImageResource(R.drawable.test_2);
                    //CheckLight();
                }else if (min >= PauseMin&&sec>=CheckPauseSec&&WhichProcess==1) {
                    TextState=0;
                    WhichProcess=2;
                    Secondbtn.setImageResource(R.drawable.ok);
                    Thirdbtn.setImageResource(R.drawable.test_3);
                    //CheckFirst();
                    SaveProcess++;
                    ShowTip2TestSecond();
                    pause = true;
                    //music();
                }else if(min>=(PauseMin*2+1)&&WhichProcess==2){
                    TextState=0;
                    WhichProcess=3;
                    Thirdbtn.setImageResource(R.drawable.getresult);
                    Thirdbtn.setOnClickListener(step3);
                    pause=true;
                    closeSession();
                    result.setText("實驗完成");
                    //music();
                }

            }
            Handler2CountTime.postDelayed(this, 500);
        }
    };

    public void init() {
        askForPermission();
        camMgr = null;
        mPreviewBuilder = null;
        mPreviewSize = null;
        mImageReader = null;

        SaveAvg_Blue = new ArrayList[3];
        SaveAvg_Red = new ArrayList[3];
        SaveAvg_Green = new ArrayList[3];
        CountPic = new int[3];
        IsPicCanTake = true;  //決定是否要取得照片
        PrepareTime = 5000;//準備啟動的時間

        SaveProcess = 0;//實驗階段 0=>第一階段 1=>第二階段
        SpendTime = 0;
        Time=0;
        PauseMin = PAUSEMIN; //min
        SaveAvg_Blue[0] = new ArrayList();
        SaveAvg_Blue[1] = new ArrayList();
        SaveAvg_Blue[2] = new ArrayList();
        SaveAvg_Green[0] = new ArrayList();
        SaveAvg_Green[1] = new ArrayList();
        SaveAvg_Green[2] = new ArrayList();
        SaveAvg_Red[0] = new ArrayList();
        SaveAvg_Red[1] = new ArrayList();
        SaveAvg_Red[2] = new ArrayList();
        CountPic[0] = 0;
        CountPic[1] = 0;
        CountPic[2] = 0;
        pause = false;
        closeSession();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.test);
        init();
        time = findViewById(R.id.time);
        result=findViewById(R.id.result);
        Firstbtn=findViewById(R.id.Firstbtn);
        Secondbtn=findViewById(R.id.Secondbtn);
        Thirdbtn=findViewById(R.id.Thirdbtn);
        backindex=findViewById(R.id.backindex);

        Firstbtn.setOnClickListener(step1);
        backindex.setOnClickListener(back);

    }
    @Override
    protected void onResume() {
        super.onResume();
        pause=false;
    }


    //ButtonEvent
    View.OnClickListener step1=new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Firstbtn.setImageResource(R.drawable.test_1);
            init();
            if(askForPermission()){
                openCamera();
            }
        }
    };
    View.OnClickListener step3=new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Change2Result();
        }
    };

    View.OnClickListener back=new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            long BeforeTime = PushBackbtnTime;
            PushBackbtnTime = System.currentTimeMillis();
            if (PushBackbtnTime - BeforeTime < 2000) {
                Change2Step();
                closeSession();
            } else {
                Toast.makeText(TestActivity.this, "再按一次停止檢驗，退回說明", Toast.LENGTH_SHORT).show();
            }
        }
    };
    //檢查光訊號是否正常
    private void CheckLight(){
        //取得15(START_LIGHTCHECK)到30(END_LIGHTCHECK)秒數值先計算標準差(SD)
        double[] SDSquareTotal=new double[3];  //0->R 1->G 2->B
        double[] SDTotal=new double[3];        //0->R 1->G 2->B
        for (int i = (int)START_LIGHTCHECK; i <  (int)END_LIGHTCHECK; i++) {
            SDSquareTotal[0] += (Double.valueOf(String.valueOf(SaveAvg_Red[0].get(i)))) * (Double.valueOf(String.valueOf(SaveAvg_Red[0].get(i))));
            SDTotal[0] += (Double.valueOf(String.valueOf(SaveAvg_Red[0].get(i))));
        }
        for (int i =  (int)START_LIGHTCHECK; i <  (int)END_LIGHTCHECK; i++) {
            SDSquareTotal[1] += (Double.valueOf(String.valueOf(SaveAvg_Green[0].get(i)))) * (Double.valueOf(String.valueOf(SaveAvg_Green[0].get(i))));
            SDTotal[1] += (Double.valueOf(String.valueOf(SaveAvg_Green[0].get(i))));
        }
        for (int i =  (int)START_LIGHTCHECK; i <  (int)END_LIGHTCHECK; i++) {
            SDSquareTotal[2] += (Double.valueOf(String.valueOf(SaveAvg_Blue[0].get(i)))) * (Double.valueOf(String.valueOf(SaveAvg_Blue[0].get(i))));
            SDTotal[2] += (Double.valueOf(String.valueOf(SaveAvg_Blue[0].get(i))));
        }
        //標準差
        double SD_R=Math.sqrt((SDSquareTotal[0]/(END_LIGHTCHECK-START_LIGHTCHECK))-(SDTotal[0]/(END_LIGHTCHECK-START_LIGHTCHECK))*(SDTotal[0]/(END_LIGHTCHECK-START_LIGHTCHECK)));
        double SD_G=Math.sqrt((SDSquareTotal[1]/(END_LIGHTCHECK-START_LIGHTCHECK))-(SDTotal[1]/(END_LIGHTCHECK-START_LIGHTCHECK))*(SDTotal[1]/(END_LIGHTCHECK-START_LIGHTCHECK)));
        double SD_B=Math.sqrt((SDSquareTotal[2]/(END_LIGHTCHECK-START_LIGHTCHECK))-(SDTotal[2]/(END_LIGHTCHECK-START_LIGHTCHECK))*(SDTotal[2]/(END_LIGHTCHECK-START_LIGHTCHECK)));
        //平均值
        double Avg_R=(SDTotal[0]/(END_LIGHTCHECK-START_LIGHTCHECK));
        double Avg_G=(SDTotal[1]/(END_LIGHTCHECK-START_LIGHTCHECK));
        double Avg_B=(SDTotal[2]/(END_LIGHTCHECK-START_LIGHTCHECK));
        //變異系數
        double cv_R=SD_R/Avg_R/100;
        double cv_G=SD_G/Avg_G/100;
        double cv_B=SD_B/Avg_B/100;

        //If (B avg< R avg) OR (B avg <G avg) Then
        //print “主光訊號偏低，請檢查量測盒是否對準鏡頭及閃光燈”
        //If (R cv + G cv +B cv>chk(0.6%) Then
        //print “光訊號不穩，請檢查量測盒黏貼情況”
        final double chk=0.6;
        if((Avg_B<Avg_R)||(Avg_B<Avg_G)){
            //主光訊號偏低，請檢查量測盒是否對準鏡頭及閃光燈
            /*pause=true;
            music();
            closeSession();
            ChangeNextbtn();*/
        }
        else if((cv_R+cv_G+cv_B)>chk){
            //光訊號不穩，請檢查量測盒黏貼情況
            /*pause=true;
            music();
            closeSession();
            ChangeNextbtn();*/
        }
        else{
            //光訊號穩定
        }
    }

    //第一階段檢查數據是否正確
    private void CheckFirst(){
        //取得開始位置和結束位置
        int StartPoint=(int)((double)(END_BLUE-START_BLUE)*START_DATAPERCENT);
        int EndPoint=(int)((double)(END_BLUE-START_BLUE)*END_DATAPERCENT);
        //建立新的陣列  P(j)=B(i+1)-B(i)，取61(START_BLUE)秒到210(END_BLUE)秒的數值
        double[] P=new double[(END_BLUE-START_BLUE)];
        for(int i=START_BLUE,j=0;i<END_BLUE-1;i++,j++){
            P[j]=((Number)SaveAvg_Blue[0].get(i+1)).doubleValue()-((Number)SaveAvg_Blue[0].get(i)).doubleValue();
        }
        Arrays.sort(P);
        //Avg
        double Avg=0;
        for (int i = StartPoint; i < EndPoint; i++) {
            Avg += P[i];
        }
        Avg /= (double)(EndPoint - StartPoint);
        //cv
        //計算標準差(SD)
        double SDSquareTotal=0;
        double SDTotal=0;
        for(int i=StartPoint,j=0;i<EndPoint;i++,j++){
            SDSquareTotal+=(P[i])*(P[i]);
            SDTotal+=(P[i]);
        }
        double SD=Math.sqrt((SDSquareTotal/=(double)(EndPoint-StartPoint))-(SDTotal/=(double)(EndPoint-StartPoint))*(SDTotal/=(double)(EndPoint-StartPoint)));
        double cv=SD/(SDTotal/=(double)(EndPoint-StartPoint));

        if(Avg>-0.008){
            //酵素或試劑似乎有問題，請再試一次
            //closeSession();
        }else{
            //光訊號穩定度:cv*100%
        }
    }

    //顯示加入蔬果汁步驟
    private void ShowTip2TestSecond(){
        Intent InStepActivity = new Intent();
        InStepActivity.setClass(TestActivity.this, FiveminDialog.class);
        startActivity(InStepActivity);
    }



    //--------------------------
    //Tool
    //--------------------------
    private double[] Arraylist2array(ArrayList arrayList){
        int size=arrayList.size();
        double[] result=new double[size];
        for(int i=0;i<size;i++){
            result[i]= (double) arrayList.get(i);
        }
        return  result;
    }

    public Bitmap processimageToBitmap(Image image) {
        Image.Plane[] planes = image.getPlanes();
        ByteBuffer buffer = planes[0].getBuffer();
        byte[] data = new byte[buffer.capacity()];
        buffer.get(data);
        final Bitmap bmp = BitmapFactory.decodeByteArray(data, 0, data.length);
        return bmp;
    }

    //取得影像RGB的平均值
    public double[] GetImageAvg(Bitmap bitmap) {
        int mBitmapWidth = bitmap.getWidth();
        int mBitmapHeight = bitmap.getHeight();
        double SaveB = 0, SaveR = 0, SaveG = 0;
        for (int i = 0; i < mBitmapHeight; i++) {
            for (int j = 0; j < mBitmapWidth; j++) {
                int color = bitmap.getPixel(j, i);
                SaveB += (color & 0xff);
                SaveR += ((color & 0xff0000) >> 16);
                SaveG += ((color & 0xff00) >> 8);
            }
        }
        SaveR /= (double) (mBitmapWidth * mBitmapHeight);
        SaveG /= (double) (mBitmapWidth * mBitmapHeight);
        SaveB /= (double) (mBitmapWidth * mBitmapHeight);
        double result[] = new double[3];

        //校正浮點數誤差值
        BigDecimal R = new BigDecimal(SaveR);
        result[0] = R.setScale(4, BigDecimal.ROUND_HALF_UP).doubleValue();
        BigDecimal G = new BigDecimal(SaveG);
        result[1] = G.setScale(4, BigDecimal.ROUND_HALF_UP).doubleValue();
        BigDecimal B = new BigDecimal(SaveB);
        result[2] = B.setScale(4, BigDecimal.ROUND_HALF_UP).doubleValue();
        return result;
    }

    //--------------------------
    //ChangePage
    //--------------------------
    public void Change2Result() {
        Handler2TakePic.removeCallbacks(runnable2TakePic);
        Handler2CountTime.removeCallbacks(runnable2CountTime);
        Intent InResultActivity = new Intent();
        InResultActivity.setClass(TestActivity.this, ResultActivity.class);
        //new一個Bundle物件，並將要傳遞的資料傳入
        Bundle bundle = new Bundle();
        bundle.putDoubleArray("PointOneB",Arraylist2array(SaveAvg_Blue[0]));
        bundle.putDoubleArray("PointTwoB",Arraylist2array(SaveAvg_Blue[1]));
        bundle.putDoubleArray("PointOneR",Arraylist2array(SaveAvg_Red[0]));
        bundle.putDoubleArray("PointTwoR",Arraylist2array(SaveAvg_Red[1]));
        bundle.putDoubleArray("PointOneG",Arraylist2array(SaveAvg_Green[0]));
        bundle.putDoubleArray("PointTwoG",Arraylist2array(SaveAvg_Green[1]));
        InResultActivity.putExtras(bundle);
        startActivity(InResultActivity);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    private void Change2Step() {
        Intent InStepActivity = new Intent();
        InStepActivity.setClass(TestActivity.this, StepActivity.class);
        startActivity(InStepActivity);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    //--------------------------
    //music
    //--------------------------
    private void music() {
        soundpool = new SoundPool(1, 0, 100);
        soundpool.load(c, R.raw.remind_ring, 1);
        soundpool.setOnLoadCompleteListener(new SoundPool.OnLoadCompleteListener() {
            @Override
            public void onLoadComplete(SoundPool soundPool, int sampleId, int status) {
                musicplay(c);
            }
        });
    }

    private void musicplay(Context c) {
        soundpool.play(1, 1, 1, 0, 0, 1);
    }

    //--------------------------
    //Camera to take picture
    //--------------------------
    public boolean askForPermission() {
        //app需要用的功能清單
        String[] permissions = new String[]{Manifest.permission.CAMERA};

        //檢查是否已經有權限
        final List<String> listPermissionsNeeded = new ArrayList<>();
        boolean bShowPermissionRationale = false;
        for (String p : permissions) {
            int result = ContextCompat.checkSelfPermission(TestActivity.this, p);
            if (result != PackageManager.PERMISSION_GRANTED) {
                listPermissionsNeeded.add(p);

                //檢查是否需要顯示說明
                if (ActivityCompat.shouldShowRequestPermissionRationale(TestActivity.this, p))
                    bShowPermissionRationale = true;
            }
        }
        //向使用者徵詢還沒有許可的權限
        if (!listPermissionsNeeded.isEmpty()) {
            if (bShowPermissionRationale) {
                AlertDialog.Builder altDlgBuilder = new AlertDialog.Builder(TestActivity.this);
                altDlgBuilder.setTitle("提示");
                altDlgBuilder.setMessage("APP需要你的許可才能執行");
                altDlgBuilder.setIcon(android.R.drawable.ic_dialog_info);
                altDlgBuilder.setCancelable(false);
                altDlgBuilder.setPositiveButton("SURE", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        ActivityCompat.requestPermissions(TestActivity.this, listPermissionsNeeded.toArray(new String[listPermissionsNeeded.size()]), REQUEST_PERMISSION_CAMERA);
                    }
                });
                altDlgBuilder.show();
            } else {
                ActivityCompat.requestPermissions(TestActivity.this, listPermissionsNeeded.toArray(new String[listPermissionsNeeded.size()]), REQUEST_PERMISSION_CAMERA);
            }
            return false;
        }
        return true;
    }

    public void openCamera() {
        //取得CameraManager
        camMgr = (CameraManager) getSystemService(CAMERA_SERVICE);
        try {
            //取得相機背後的camera
            cameraID = camMgr.getCameraIdList()[0];
            CameraCharacteristics camChar = camMgr.getCameraCharacteristics(cameraID);
            //取得解析度
            StreamConfigurationMap map = camChar.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            mPreviewSize = map.getOutputSizes(SurfaceTexture.class)[0];
            //啟動camera
            if (ContextCompat.checkSelfPermission(TestActivity.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                camMgr.openCamera(cameraID, mCameraStateCallback,null);
            }
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }

    private CameraDevice.StateCallback mCameraStateCallback = new CameraDevice.StateCallback() {
        @Override
        public void onOpened(CameraDevice camera) {
            mcameraDevice = camera;
            StartTakePic();
            Handler2TakePic.postDelayed(runnable2TakePic, PrepareTime);
            Handler2CountTime.postDelayed(runnable2CountTime, PrepareTime);
            Log.d("Testcamera","OKOK");
        }

        @Override
        public void onDisconnected(CameraDevice camera) {
            mcameraDevice.close();
            mcameraDevice = null;
        }

        @Override
        public void onError(CameraDevice camera, int error) {
            Toast.makeText(TestActivity.this, "Camera開啟錯誤", Toast.LENGTH_LONG).show();
            Log.d("Testcamera", String.valueOf(error));
        }
    };

    private void StartTakePic() {
        //設定camera的CaptureRequest和CaptureSession
        try {
            mPreviewBuilder = mcameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
        mImageReader = ImageReader.newInstance(640, 480, ImageFormat.JPEG, 10);
        HandlerThread thread = new HandlerThread("CameraTakePicture");
        thread.start();
        final Handler backgroundHandler = new Handler(thread.getLooper());
        mImageReader.setOnImageAvailableListener(imageAvailableListener, backgroundHandler);
        mPreviewBuilder.addTarget(mImageReader.getSurface());
        try {
            mcameraDevice.createCaptureSession(Arrays.asList(mImageReader.getSurface()), mCameraCaptureSessionCallback, null);
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }

    //Camera的CaptureSession狀態改變的時候執行
    private CameraCaptureSession.StateCallback mCameraCaptureSessionCallback = new CameraCaptureSession.StateCallback() {
        @Override
        public void onConfigured(CameraCaptureSession session) {
            mPreviewBuilder.set(CaptureRequest.FLASH_MODE, CameraMetadata.FLASH_MODE_TORCH);
            mPreviewBuilder.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_ON);
            mPreviewBuilder.set(CaptureRequest.CONTROL_AWB_MODE,CameraMetadata.CONTROL_AWB_STATE_LOCKED);

            CameraSession = session;

            HandlerThread backgroundThread = new HandlerThread("camerapreview");
            backgroundThread.start();
            Handler backgroundHandler = new Handler(backgroundThread.getLooper());
            try {
                CameraSession.setRepeatingRequest(mPreviewBuilder.build(), null, backgroundHandler);
            } catch (CameraAccessException e) {
                e.printStackTrace();
            }
            backgroundThread.quit();

        }

        @Override
        public void onConfigureFailed(CameraCaptureSession session) {
            Toast.makeText(TestActivity.this, "Camera預覽錯誤", Toast.LENGTH_LONG).show();
        }
    };

    ImageReader.OnImageAvailableListener imageAvailableListener = new ImageReader.OnImageAvailableListener() {
        @Override
        public void onImageAvailable(ImageReader reader) {
            //讀取到影像資料
            Image image = null;
            try {
                image = reader.acquireLatestImage();
                if (IsPicCanTake && SaveProcess < 2 && image != null) {
                    IsPicCanTake = false;
                    Bitmap b = processimageToBitmap(image);
                    double[] Avg = GetImageAvg(b);
                    SaveAvg_Red[SaveProcess].add(CountPic[SaveProcess], Avg[0]);
                    SaveAvg_Green[SaveProcess].add(CountPic[SaveProcess], Avg[1]);
                    SaveAvg_Blue[SaveProcess].add(CountPic[SaveProcess], Avg[2]);
                    CountPic[SaveProcess]++;
                    Time++;
                    //if user want to saveimage
                    //SaveImage(b,CountPic[0]+CountPic[1]);
                }
            } finally {
                if (image != null) {
                    image.close();
                }
            }
        }

    };
    public void closeSession() {
        if (CameraSession != null) {
            CameraSession.close();
            CameraSession = null;
            mcameraDevice.close();
            mcameraDevice = null;

        }
    }

    //額外功能
    public void SaveImage(Bitmap bitmap, int CountPic) {
        try {
            // 取得外部儲存裝置路徑
            String path = Environment.getExternalStorageDirectory().toString();
            // 開啟檔案
            File file = new File(path + "/PIC", "Image_" + CountPic + ".png");
            // 開啟檔案串流
            FileOutputStream out = new FileOutputStream(file);
            // 將 Bitmap壓縮成指定格式的圖片並寫入檔案串流
            bitmap.compress(Bitmap.CompressFormat.PNG, 90, out);
            // 刷新並關閉檔案串流
            out.flush();
            out.close();
            Uri uri = Uri.fromFile(file);
            sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, uri));
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}

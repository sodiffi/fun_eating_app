package com.mobilezme.tony.pesticsdedetect;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;

public class LineCanvas extends View {
    private Paint p = new Paint();
    private Canvas c = new Canvas();
    public DrawImage DI;
    private DrawLine DL;
    private Bitmap newb;
    private ArrayList<Point> points;
    private double CanvasW;
    private double CanvasH;
    private TestActivity testActivity;
    public boolean showTip=false,showFinalbtn=false;

    public LineCanvas(Context context,TestActivity testActivity) {
        super(context);
        this.testActivity=testActivity;
        DI = new DrawImage(context);
        points=new ArrayList<Point>();
        DL=new DrawLine(points);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        c = canvas;
        p.setColor(getResources().getColor(R.color.orange));
        p.setStrokeWidth(4);
        CanvasW=(double)c.getWidth()/(double)420;
        CanvasH=(double)c.getHeight()/(double)255;

        //DrawLine
        DL.setPoints(points);
        DL.draw(c,p);

        //Event
        if(DI.state)
            newb = DI.getImage(R.drawable.test_startbtn_up, 0.55, 0.55, p, c);
        else
            newb = DI.getImage(R.drawable.test_startbtn_down, 0.55, 0.55, p, c);
        DI.setXposition((c.getWidth() - DI.getWidth()) / 2);
        DI.setYposition((c.getHeight() - DI.getHeight()) / 2);
        if(DI.visible)
            c.drawBitmap(newb, DI.getXposition(), DI.getYposition(), p);
        newb.recycle();

        //Tip
        if(showTip&&DI.visible){
            newb = DI.getImage(R.drawable.test_tip, 0.65, 0.65, p, c);
            DI.setXposition((c.getWidth() - DI.getWidth()) / 2);
            DI.setYposition((c.getHeight() - DI.getHeight()) / 2);
            c.drawBitmap(newb, DI.getXposition(), DI.getYposition(), p);
            int tip_width=(c.getWidth() - DI.getWidth()) / 2+DI.getWidth();
            if(DI.state)
                newb = DI.getImage(R.drawable.test_tipbtn_up, 0.35, 0.35, p, c);
            else
                newb = DI.getImage(R.drawable.test_tipbtn_down, 0.35, 0.35, p, c);
            DI.setXposition(tip_width-(int)(DI.getWidth()*1.3));
            DI.setYposition((c.getHeight()/2)-(DI.getHeight()/2));
            c.drawBitmap(newb, DI.getXposition(), DI.getYposition(), p);
            newb.recycle();

        }

        //final
        if(showFinalbtn&&DI.visible){
            if(DI.state)
                newb = DI.getImage(R.drawable.test_2resultbtn_up, 0.55, 0.55, p, c);
            else
                newb = DI.getImage(R.drawable.test_2resultbtn_down, 0.55, 0.55, p, c);
            DI.setXposition((c.getWidth() - DI.getWidth()) / 2);
            DI.setYposition((c.getHeight() - DI.getHeight()) / 2);
            c.drawBitmap(newb, DI.getXposition(), DI.getYposition(), p);
            newb.recycle();
        }




    }


    //Get Touch position X and Y
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float x = event.getX();
        float y = event.getY();
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    if (x > DI.getXposition() && x < DI.getXposition() + DI.getWidth() && y > DI.getYposition() && y < DI.getYposition() + DI.getHeight()&& DI.visible == true) {
                        DI.state = false;
                        DI.visible = true;
                        invalidate();
                        return true;
                    }
                case MotionEvent.ACTION_UP:
                    if (x > DI.getXposition() && x < DI.getXposition() + DI.getWidth() && y > DI.getYposition() && y < DI.getYposition() + DI.getHeight()&& DI.visible == true) {
                        DI.state = true;
                        DI.visible = false;
                        if (testActivity.askForPermission()&&DI.WhichProcess==0){
                            testActivity.openCamera();
                            //testActivity.TestDraw();
                        }
                        else if(testActivity.pause==true&&DI.WhichProcess==1){
                            testActivity.pause=false;
                            showTip=false;
                        }else if(testActivity.pause==true&&DI.WhichProcess==2){
                            testActivity.Change2Result();
                            testActivity.closeSession();
                        }
                        invalidate();
                        return true;
                    }
            }
        return false;
    }

    public void getPoint(int PointX,double PointY){

        Point p=new Point((int)((double)PointX*CanvasW),(int)((CanvasH*255)-(int)PointY*CanvasH));
        points.add(p);
        postInvalidate();
    }
}


class DrawImage {
        private int width,height,Xposition,Yposition;
        private View v;
        private Bitmap b;
        public boolean state,visible;
        public int WhichProcess=0; //實驗階段 0=>第一階段 1=>第二階段
        DrawImage(Context context){
            v=new View(context);
            state=true;
            visible=true;
        }
        public void init(){
            state=true;
            visible=true;
            width=0;
            height=0;
            Xposition=0;
            Yposition=0;
            b=null;
        }

    public int getHeight() {
        if(b!=null)
            return height;
        else
            return -1;
    }

    public int getWidth() {
            if(b!=null)
                return width;
            else
                return -1;
    }

    public void setXposition(int xposition) {
        Xposition = xposition;
    }

    public int getXposition() {
            if(b!=null)
                return Xposition;
            else
                return -1;
    }
    public void setYposition(int yposition) {
        Yposition = yposition;
    }

    public int getYposition() {
        if(b!=null)
            return Yposition;
        else
            return -1;
    }

    public Bitmap getImage(int Image, double scaleX, double scaleY, Paint p, Canvas c) {
        b = BitmapFactory.decodeResource(v.getResources(), Image);
        width = (int) ((double)b.getWidth() * scaleX);
        height = (int) ((double)b.getHeight() * scaleY);
        b = Bitmap.createScaledBitmap(b, width, height, false);
        return b;
    }
}
class DrawLine{
    ArrayList<Point> points;
    DrawLine(ArrayList<Point> p){
        points=p;
    }

    public void setPoints(ArrayList<Point> points) {
        this.points = points;
    }

    public void draw(Canvas c, Paint p){
        for(int i=1;i<points.size();i++){
            c.drawLine(points.get(i-1).x,points.get(i-1).y,points.get(i).x,points.get(i).y,p);
        }
    }
}



